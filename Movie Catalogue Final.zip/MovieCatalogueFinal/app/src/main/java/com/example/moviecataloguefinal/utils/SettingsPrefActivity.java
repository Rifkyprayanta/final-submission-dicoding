package com.example.moviecataloguefinal.utils;

import android.content.Intent;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.SwitchPreference;
import android.provider.Settings;

import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.model.Movies;
import com.example.moviecataloguefinal.notif.NotifReceiver;

import java.util.ArrayList;
import java.util.List;

public class SettingsPrefActivity extends AppCompatPreferenceActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getFragmentManager().beginTransaction().replace(android.R.id.content, new MainPreferenceFragment()).commit();
    }

    public static class MainPreferenceFragment extends PreferenceFragment implements Preference.OnPreferenceChangeListener {
        SwitchPreference switchReminder;
        SwitchPreference switchToday;

        NotifReceiver notifReceiver = new NotifReceiver();

        List<Movies> moviesList;
        List<Movies> sameMoviesList;

        @Override
        public void onCreate(final Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_main);

            moviesList = new ArrayList<>();
            sameMoviesList = new ArrayList<>();

            switchReminder = (SwitchPreference) findPreference(getString(R.string.key_today_reminder));
            switchReminder.setOnPreferenceChangeListener(this);
            switchToday = (SwitchPreference) findPreference(getString(R.string.key_release_reminder));
            switchToday.setOnPreferenceChangeListener(this);

            Preference myPref = findPreference("key_lang");
            myPref.setOnPreferenceClickListener(preference -> {
                startActivity(new Intent(Settings.ACTION_LOCALE_SETTINGS));

                return true;
            });

        }

        @Override
        public boolean onPreferenceChange(Preference preference, Object newValue) {
            String key = preference.getKey();
            boolean b = (boolean) newValue;

            if(key.equals(getString(R.string.key_today_reminder))){
                if(b){
                    notifReceiver.setAlarm(getActivity(), NotifReceiver.DAILY_ALARM_ID, 7);
                }else{
                    notifReceiver.cancelAlarm(getActivity(), NotifReceiver.DAILY_ALARM_ID);
                }
            }else{
                if(b){
                    notifReceiver.setAlarm(getActivity(), NotifReceiver.RELEASE_ALARM_ID, 8);
                }else{
                    notifReceiver.cancelAlarm(getActivity(), NotifReceiver.RELEASE_ALARM_ID);
                }
            }
            return true;
        }
    }
}
