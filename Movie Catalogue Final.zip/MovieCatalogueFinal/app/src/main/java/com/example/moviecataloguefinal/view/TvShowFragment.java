package com.example.moviecataloguefinal.view;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;

import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.adapter.TvShowAdapter;
import com.example.moviecataloguefinal.model.TvShow;
import com.example.moviecataloguefinal.viewmodel.TvShowViewModel;

import java.util.ArrayList;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 */
public class TvShowFragment extends Fragment implements android.widget.SearchView.OnQueryTextListener {

    private final int laman = 2;
    private TvShowAdapter adapter;
    private ProgressBar pbTvShow;
    private SearchView svTvShow;
    private RecyclerView rvList;
    private TvShowViewModel tvShowViewModel;
    private TextView tvGagal;
    private Handler mHandler;

    private final Observer<ArrayList<TvShow>> observer = new Observer<ArrayList<TvShow>>() {
        @Override
        public void onChanged(@Nullable ArrayList<TvShow> tvShows) {
            if (tvShows != null) {
                adapter.setTvShow(tvShows);
                setProgressBarVisible(false);

                if (tvShows.size() <= 0) {
                    pbTvShow.setVisibility(View.GONE);
                    tvGagal.setVisibility(View.VISIBLE);
                } else {
                    tvGagal.setVisibility(View.GONE);
                }
            }
        }
    };

    public TvShowFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movies, container, false);

        tvGagal = view.findViewById(R.id.tvGagal);
        pbTvShow = view.findViewById(R.id.pbMovie);
        svTvShow = view.findViewById(R.id.search);
        rvList = view.findViewById(R.id.rvMovie);

        adapter = new TvShowAdapter(getActivity());
        mHandler = new Handler();

        rvList.setHasFixedSize(true);
        rvList.setLayoutManager(new LinearLayoutManager(getContext()));
        rvList.setAdapter(adapter);

        svTvShow.setQueryHint("Search");
        svTvShow.setOnQueryTextListener(this);

        tvShowViewModel = ViewModelProviders.of(this).get(TvShowViewModel.class);
        tvShowViewModel.getAllTvShow().observe(getViewLifecycleOwner(), observer);

        if (adapter.getItemCount() <= 0 && (tvGagal.getVisibility() == View.GONE)) {
            tvShowViewModel.loadTvShow(laman);
        }

        return view;
    }

    private void setProgressBarVisible(Boolean state) {
        if (state) {
            pbTvShow.setVisibility(View.VISIBLE);
            svTvShow.setVisibility(View.GONE);
        } else {
            pbTvShow.setVisibility(View.GONE);
            svTvShow.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        if (query.trim().isEmpty()) return false;

        setProgressBarVisible(true);
        adapter.deleteTvShow();

        tvGagal.setVisibility(View.GONE);

        tvShowViewModel.searchTvShow(query);

        rvList.smoothScrollToPosition(0);
        return true;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        mHandler.removeCallbacksAndMessages(null);

        mHandler.postDelayed(() -> {
            if (TextUtils.isEmpty(newText)) {
                tvShowViewModel.loadTvShow(laman);
            } else {
                tvShowViewModel.searchTvShow(newText);
            }
        }, 300);

        return true;
    }

}
