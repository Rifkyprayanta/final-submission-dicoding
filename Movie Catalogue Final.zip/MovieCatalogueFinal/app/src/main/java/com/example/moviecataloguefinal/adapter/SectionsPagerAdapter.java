package com.example.moviecataloguefinal.adapter;

import android.content.Context;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.view.FavoriteFragment;
import com.example.moviecataloguefinal.view.FavoriteTvShowFragment;
import com.example.moviecataloguefinal.view.MoviesFragment;
import com.example.moviecataloguefinal.view.TvShowFragment;

public class SectionsPagerAdapter extends FragmentPagerAdapter {

    private final Context mContext;
    public SectionsPagerAdapter(Context context, FragmentManager fm) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mContext = context;
    }

    @StringRes
    private final int[] TAB_TITLES = new int[]{
            R.string.movie_title,
            R.string.tvshow_title,
            R.string.favorite_title,
            R.string.favorite_tvshow_title
    };
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        switch (position) {
            case 0:
                fragment = new MoviesFragment();
                break;
            case 1:
                fragment = new TvShowFragment();
                break;
            case 2:
                fragment = new FavoriteFragment();
                break;
            case 3:
                fragment = new FavoriteTvShowFragment();
                break;
        }
        return fragment;
    }
    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mContext.getResources().getString(TAB_TITLES[position]);
    }
    @Override
    public int getCount() {
        return 4;
    }
}
