package com.example.moviecataloguefinal.db;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.moviecataloguefinal.api.ApiClient;
import com.example.moviecataloguefinal.api.TMDBApi;
import com.example.moviecataloguefinal.model.Movies;

import java.util.List;

public class FavoriteMoviesRepository {

    private final MoviesDao moviesDao;
    private final LiveData<List<Movies>> allMovies;

    public FavoriteMoviesRepository(Application application) {
        FavDb database = FavDb.getInstance(application);
        moviesDao = database.moviesDao();
        allMovies = moviesDao.getAllMovies();
    }

    public void insert(Movies movies, MoviesFactoryListener listener) {
        new InsertMovieTask(moviesDao, listener).execute(movies);
    }

    public void delete(Movies movies, MoviesFactoryListener listener) {
        new DeleteMovieTask(moviesDao, listener).execute(movies);
    }

    public LiveData<List<Movies>> getAllMovies() {
        return allMovies;
    }

    public void getMovieById(int id, MoviesFactoryListener listener) {
        new GetMovieByIdTask(moviesDao, listener).execute(id);
    }

    public interface MoviesFactoryListener {
        void onMoviesReceived(Movies movies);

        void onMoviesInserted();

        void onMoviesDeleted();
    }

    private static class InsertMovieTask extends AsyncTask<Movies, Void, Void> {
        private final MoviesDao moviesDao;
        private final MoviesFactoryListener listener;

        InsertMovieTask(MoviesDao moviesDao, MoviesFactoryListener listener) {
            this.moviesDao = moviesDao;
            this.listener = listener;
        }

        @Override
        protected Void doInBackground(Movies... movies) {
            moviesDao.insert(movies[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            listener.onMoviesInserted();
        }
    }

    private static class DeleteMovieTask extends AsyncTask<Movies, Void, Void> {
        private final MoviesDao moviesDao;
        private final MoviesFactoryListener listener;

        DeleteMovieTask(MoviesDao moviesDao, MoviesFactoryListener listener) {
            this.moviesDao = moviesDao;
            this.listener = listener;
        }

        @Override
        protected Void doInBackground(Movies... movies) {
            moviesDao.delete(movies[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            listener.onMoviesDeleted();
        }
    }

    private static class GetMovieByIdTask extends AsyncTask<Integer, Void, Void> {
        private final MoviesDao moviesDao;
        private Movies movies;
        private final MoviesFactoryListener listener;

        GetMovieByIdTask(MoviesDao moviesDao, MoviesFactoryListener listener) {
            this.moviesDao = moviesDao;
            this.listener = listener;
        }

        @Override
        protected Void doInBackground(Integer... ints) {
            movies = moviesDao.getMovieById(ints[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            listener.onMoviesReceived(movies);
        }
    }

    public List<Movies> getAllMoviesAsList() {
        return moviesDao.getAllMoviesAsList();
    }
}
