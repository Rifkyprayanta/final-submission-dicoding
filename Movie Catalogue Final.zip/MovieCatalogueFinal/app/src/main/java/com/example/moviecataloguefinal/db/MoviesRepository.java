package com.example.moviecataloguefinal.db;

import android.content.Context;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.moviecataloguefinal.api.ApiClient;
import com.example.moviecataloguefinal.api.TMDBApi;
import com.example.moviecataloguefinal.api.response.MoviesResponse;
import com.example.moviecataloguefinal.model.Movies;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MoviesRepository {
    private final TMDBApi mClient = ApiClient.getClient();
    private final Context mContext;

    public MoviesRepository(Context context) {
        this.mContext = context;
    }

    public void getMovies(int page, MoviesListener listener) {
        mClient.getMovies(page).enqueue(new Callback<MoviesResponse>() {
            @Override
            public void onResponse(@NonNull Call<MoviesResponse> call, @NonNull Response<MoviesResponse> response) {
                if (response.body() != null) {
                    listener.onMoviesReceived(response.body().getMovies());
                }
            }

            @Override
            public void onFailure(@NonNull Call<MoviesResponse> call, @NonNull Throwable t) {
                Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public void searchMovies(String query, MoviesListener listener) {
        mClient.searchMovies(query).enqueue(new Callback<MoviesResponse>() {
            @Override
            public void onResponse(@NonNull Call<MoviesResponse> call, @NonNull Response<MoviesResponse> response) {
                if (response.body() != null) {
                    listener.onMoviesReceived(response.body().getMovies());
                }
            }

            @Override
            public void onFailure(@NonNull Call<MoviesResponse> call, @NonNull Throwable t) {
                Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public interface MoviesListener {
        void onMoviesReceived(ArrayList<Movies> movies);
    }
}
