package com.example.moviecataloguefinal.db;

import android.content.Context;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.moviecataloguefinal.api.ApiClient;
import com.example.moviecataloguefinal.api.TMDBApi;
import com.example.moviecataloguefinal.api.response.TvShowResponse;
import com.example.moviecataloguefinal.model.TvShow;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TvShowRepository {

    private final TMDBApi mClient = ApiClient.getClient();
    private final Context mContext;

    public TvShowRepository(Context mContext) {
        this.mContext = mContext;
    }

    public void getTvShow(int page, TvShowListener listener) {
        mClient.getSeries(page).enqueue(new Callback<TvShowResponse>() {
            @Override
            public void onResponse(@NonNull Call<TvShowResponse> call, @NonNull Response<TvShowResponse> response) {
                if (response.body() != null) {
                    listener.onShowsReceived(response.body().getSeries());
                }
            }

            @Override
            public void onFailure(@NonNull Call<TvShowResponse> call, @NonNull Throwable t) {
                Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public void searchTvShow (String query, TvShowListener listener) {
        mClient.searchSeries(query).enqueue(new Callback<TvShowResponse>() {
            @Override
            public void onResponse(@NonNull Call<TvShowResponse> call, @NonNull Response<TvShowResponse> response) {
                if (response.body() != null) {
                    listener.onShowsReceived(response.body().getSeries());
                }
            }

            @Override
            public void onFailure(@NonNull Call<TvShowResponse> call, @NonNull Throwable t) {
                Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public interface TvShowListener {
        void onShowsReceived(ArrayList<TvShow> tvShow);
    }
}
