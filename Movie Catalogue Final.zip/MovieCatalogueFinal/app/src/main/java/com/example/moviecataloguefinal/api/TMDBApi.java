package com.example.moviecataloguefinal.api;

import com.example.moviecataloguefinal.BuildConfig;
import com.example.moviecataloguefinal.api.response.MoviesResponse;
import com.example.moviecataloguefinal.api.response.TvShowResponse;
import com.example.moviecataloguefinal.model.Movies;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface TMDBApi {

    @GET("movie/popular")
    Call<MoviesResponse> getPopularMovies(
            @Query("api_key") String apiKey,
            @Query("language") String language,
            @Query("page") int page
    );

    @GET("tv/popular")
    Call<TvShowResponse> getPopularTVShow(
            @Query("api_key") String apiKey,
            @Query("language") String language,
            @Query("page") int page
    );

    @GET("movie/popular?language=en-US&api_key=" + BuildConfig.API_KEY)
    Call<MoviesResponse> getMovies(@Query("page") int page);

    @GET("tv/popular?language=en-US&api_key=" + BuildConfig.API_KEY)
    Call<TvShowResponse> getSeries(@Query("page") int page);

    @GET("search/movie?language=en-US&api_key=" + BuildConfig.API_KEY)
    Call<MoviesResponse> searchMovies(@Query("query") String query);

    @GET("search/tv?language=en-US&api_key=" + BuildConfig.API_KEY)
    Call<TvShowResponse> searchSeries(@Query("query") String query);

    @GET("movie/{id}?language=en-US&api_key=" + BuildConfig.API_KEY)
    Call<Movies> getMovieById(@Path("id") int id);

    @GET("discover/movie?language=en-US&page=1&api_key=" + BuildConfig.API_KEY)
    Call<MoviesResponse> getMovieByReleaseRange(@Query("primary_release_date.lte") String releaseDateLte, @Query("primary_release_date.gte") String releaseDateGte, @Query("sort_by") String sortBy);
}
