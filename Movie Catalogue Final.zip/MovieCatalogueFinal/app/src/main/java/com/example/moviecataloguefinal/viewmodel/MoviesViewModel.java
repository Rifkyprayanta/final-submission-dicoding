package com.example.moviecataloguefinal.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.moviecataloguefinal.db.MoviesRepository;
import com.example.moviecataloguefinal.model.Movies;

import java.util.ArrayList;

public class MoviesViewModel extends AndroidViewModel {

    private final MoviesRepository repository;
    private final MutableLiveData<ArrayList<Movies>> allMovies = new MutableLiveData<>();

    public MoviesViewModel(@NonNull Application application) {
        super(application);

        repository = new MoviesRepository(application);
    }

    public void loadMovies(int page) {
        repository.getMovies(page, allMovies::postValue);
    }

    public void searchMovies(String query) {
        repository.searchMovies(query, allMovies::postValue);
    }

    public LiveData<ArrayList<Movies>> getAllMovies() {
        return allMovies;
    }
}
