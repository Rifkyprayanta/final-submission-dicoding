package com.example.moviecataloguefinal.db;

import android.database.Cursor;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.moviecataloguefinal.model.Movies;

import java.util.List;

@Dao
public interface MoviesDao {
    @Insert
    void insert(Movies movies);

    @Delete
    void delete(Movies movies);

    @Query("SELECT * FROM movies")
    LiveData<List<Movies>> getAllMovies();

    @Query("SELECT * FROM movies WHERE id=:id")
    Movies getMovieById(int id);

    @Query("SELECT * FROM movies")
    List<Movies> getAllMoviesAsList();

    @Query("SELECT * FROM movies")
    Cursor getAllMoviesCursor();
}
