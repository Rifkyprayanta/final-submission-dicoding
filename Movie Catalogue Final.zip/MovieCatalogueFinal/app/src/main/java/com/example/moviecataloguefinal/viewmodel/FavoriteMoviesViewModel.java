package com.example.moviecataloguefinal.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.moviecataloguefinal.db.FavoriteMoviesRepository;
import com.example.moviecataloguefinal.model.Movies;

import java.util.List;

public class FavoriteMoviesViewModel extends AndroidViewModel {

    private final FavoriteMoviesRepository repository;
    private final LiveData<List<Movies>> allMovies;

    public FavoriteMoviesViewModel(@NonNull Application application) {
        super(application);

        repository = new FavoriteMoviesRepository(application);
        allMovies = repository.getAllMovies();
    }

    public void insert(Movies movies, FavoriteMoviesRepository.MoviesFactoryListener listener) {
        repository.insert(movies, listener);
    }

    public void delete(Movies movies, FavoriteMoviesRepository.MoviesFactoryListener listener) {
        repository.delete(movies, listener);
    }

    public void getMovieById(int id, FavoriteMoviesRepository.MoviesFactoryListener listener) {
        repository.getMovieById(id, listener);
    }

    public LiveData<List<Movies>> getAllMovies() {
        return allMovies;
    }
}
