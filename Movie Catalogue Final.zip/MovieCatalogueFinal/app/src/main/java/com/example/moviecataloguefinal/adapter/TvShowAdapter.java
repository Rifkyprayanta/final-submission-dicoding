package com.example.moviecataloguefinal.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.model.TvShow;
import com.example.moviecataloguefinal.utils.CustomOnItemClickListener;
import com.example.moviecataloguefinal.view.DetailActivityTvShow;

import java.util.ArrayList;

public class TvShowAdapter extends RecyclerView.Adapter<TvShowAdapter.TvShowViewHolder> {

    private String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w185";

    private final Context context;
    private final ArrayList<TvShow> tvShows = new ArrayList<>();

    public TvShowAdapter(Context context) {
        this.context = context;
    }

    public void setTvShow(ArrayList<TvShow> tvShow) {
        this.tvShows.clear();
        this.tvShows.addAll(tvShow);
        notifyDataSetChanged();
    }

    public void deleteTvShow() {
        this.tvShows.clear();
    }

    @NonNull
    @Override
    public TvShowViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemRow = LayoutInflater.from(context).inflate(R.layout.item_movies, parent, false);
        return new TvShowViewHolder(itemRow);
    }

    @Override
    public void onBindViewHolder(@NonNull final TvShowViewHolder holder, int i) {
        holder.bind(tvShows.get(i));

        holder.itemView.setOnClickListener(new CustomOnItemClickListener(i, position -> {
            Intent moveIntent = new Intent(context, DetailActivityTvShow.class);
            moveIntent.putExtra(DetailActivityTvShow.EXTRA_TVSHOWS, tvShows.get(i));
            context.startActivity(moveIntent);
        }));
    }

    @Override
    public int getItemCount() {
        return tvShows.size();
    }

    public class TvShowViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        TextView tvFirstAirDate;
        TextView tvvoteAverage;
        TextView tvpopularity;
        TextView tvOverview;
        ImageView imgPhoto;

        public TvShowViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.title);
            tvFirstAirDate = itemView.findViewById(R.id.releaseDate);
            tvvoteAverage= itemView.findViewById(R.id.voteAverage);
            tvpopularity= itemView.findViewById(R.id.popularity);
            tvOverview = itemView.findViewById(R.id.overview);
            imgPhoto = itemView.findViewById(R.id.imgPhoto);
        }

        public void bind(TvShow tvShow) {
            tvName.setText(tvShow.getName());
            tvFirstAirDate.setText(tvShow.getFirstAirDate());
            tvvoteAverage.setText(tvShow.getVoteAverage() + "/10");
            tvpopularity.setText(tvShow.getPopularity());
            tvOverview.setText(tvShow.getOverview());
            Glide.with(itemView)
                    .load(IMAGE_BASE_URL + tvShow.getPosterPath())
                    .apply(RequestOptions.placeholderOf(R.color.colorPrimary))
                    .into(imgPhoto);
        }
    }
}
