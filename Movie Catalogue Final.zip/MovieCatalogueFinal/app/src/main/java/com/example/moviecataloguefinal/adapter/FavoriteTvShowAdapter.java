package com.example.moviecataloguefinal.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.model.TvShow;
import com.example.moviecataloguefinal.utils.CustomOnItemClickListener;
import com.example.moviecataloguefinal.view.DetailActivityTvShow;

import java.util.ArrayList;
import java.util.List;

public class FavoriteTvShowAdapter extends RecyclerView.Adapter<FavoriteTvShowAdapter.FavoriteTvShowViewHolder>{

    private String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w185";

    private final Context context;
    private List<TvShow> favoriteTvShow = new ArrayList<>();

    public FavoriteTvShowAdapter(Context context)
    {
        this.context = context;
    }

    public void setFavoriteTvShow(List<TvShow> favoriteTvShow) {
        this.favoriteTvShow = favoriteTvShow;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FavoriteTvShowViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemRow = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movies, parent, false);
        return new FavoriteTvShowAdapter.FavoriteTvShowViewHolder(itemRow);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteTvShowViewHolder holder, int i) {
        holder.bind(favoriteTvShow.get(i));

        holder.itemView.setOnClickListener(new CustomOnItemClickListener(i, position -> {
            Intent moveIntent = new Intent(context, DetailActivityTvShow.class);
            moveIntent.putExtra(DetailActivityTvShow.EXTRA_TVSHOWS, favoriteTvShow.get(i));
            context.startActivity(moveIntent);
        }));
    }


    @Override
    public int getItemCount() {
        return favoriteTvShow.size();
    }

    class FavoriteTvShowViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvTitle;
        TextView tvFirstAirDate;
        TextView voteAverage;
        TextView popularity;
        TextView tvOverview;
        ImageView imgPhoto;

        public FavoriteTvShowViewHolder (View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.title);
            tvFirstAirDate = itemView.findViewById(R.id.releaseDate);
            voteAverage= itemView.findViewById(R.id.voteAverage);
            popularity= itemView.findViewById(R.id.popularity);
            tvOverview = itemView.findViewById(R.id.overview);
            imgPhoto = itemView.findViewById(R.id.imgPhoto);
        }

        public void bind(TvShow tvShow) {
            tvTitle.setText(tvShow.getName());
            tvFirstAirDate.setText(tvShow.getFirstAirDate());
            voteAverage.setText(tvShow.getVoteAverage() + "/10");
            popularity.setText(tvShow.getPopularity());
            tvOverview.setText(tvShow.getOverview());

            Glide.with(itemView)
                    .load(IMAGE_BASE_URL + tvShow.getPosterPath())
                    .apply(RequestOptions.placeholderOf(R.color.colorPrimary))
                    .into(imgPhoto);
        }
    }
}
