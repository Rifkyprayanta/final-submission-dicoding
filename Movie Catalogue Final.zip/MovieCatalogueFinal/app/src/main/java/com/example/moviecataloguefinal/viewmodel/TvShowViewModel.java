package com.example.moviecataloguefinal.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.moviecataloguefinal.db.TvShowRepository;
import com.example.moviecataloguefinal.model.TvShow;

import java.util.ArrayList;

public class TvShowViewModel extends AndroidViewModel {

    private final TvShowRepository repository;
    private final MutableLiveData<ArrayList<TvShow>> allTvShow = new MutableLiveData<>();

    public TvShowViewModel(@NonNull Application application) {
        super(application);

        repository = new TvShowRepository(application);
    }

    public void loadTvShow(int page) {
        repository.getTvShow(page, allTvShow::postValue);
    }

    public void searchTvShow(String query) {
        repository.searchTvShow(query, allTvShow::postValue);
    }

    public LiveData<ArrayList<TvShow>> getAllTvShow() {
        return allTvShow;
    }
}
