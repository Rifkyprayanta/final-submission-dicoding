package com.example.moviecataloguefinal.api.response;

import android.os.Parcel;
import android.os.Parcelable;

import com.example.moviecataloguefinal.model.Movies;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class MoviesResponse implements Parcelable{

    @SerializedName("results")
    private ArrayList<Movies> movies;

    public ArrayList<Movies> getMovies() {
        return movies;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(this.movies);
    }

    protected MoviesResponse(Parcel in) {
        this.movies = in.createTypedArrayList(Movies.CREATOR);
    }

    public static final Parcelable.Creator<MoviesResponse> CREATOR = new Parcelable.Creator<MoviesResponse>() {
        @Override
        public MoviesResponse createFromParcel(Parcel source) {
            return new MoviesResponse(source);
        }

        @Override
        public MoviesResponse[] newArray(int size) {
            return new MoviesResponse[size];
        }
    };
}
