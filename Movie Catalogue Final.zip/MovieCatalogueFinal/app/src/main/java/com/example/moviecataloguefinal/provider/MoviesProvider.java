package com.example.moviecataloguefinal.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.moviecataloguefinal.db.FavDb;
import com.example.moviecataloguefinal.db.MoviesDao;

import java.util.Objects;

public class MoviesProvider extends ContentProvider {

    private static final String AUTHORITY = "com.example.moviecataloguefinal";
    private static final String BASE_PATH = "movies";

    private static final int MOVIES = 1;

    private static final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {
        uriMatcher.addURI(AUTHORITY, BASE_PATH, MOVIES);
    }

    private MoviesDao moviesDao;

    @Override
    public boolean onCreate() {
        moviesDao = FavDb.getInstance(getContext()).moviesDao();
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        Cursor cursor = null;

        if (uriMatcher.match(uri) == MOVIES) {
            cursor = moviesDao.getAllMoviesCursor();
            cursor.setNotificationUri(Objects.requireNonNull(getContext()).getContentResolver(), uri);
        }

        return cursor;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
