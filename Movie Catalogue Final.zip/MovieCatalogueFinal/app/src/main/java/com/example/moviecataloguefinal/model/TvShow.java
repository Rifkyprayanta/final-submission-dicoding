package com.example.moviecataloguefinal.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Objects;

@Entity(tableName = "tvshow")
public class TvShow implements Parcelable {

    @NonNull
    @PrimaryKey
    @SerializedName("id")
    private String id;

    @SerializedName("poster_path")
    @Expose
    private String posterPath;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("first_air_date")
    @Expose
    private String firstAirDate;
    @SerializedName("popularity")
    @Expose
    private String popularity;
    @SerializedName("vote_average")
    @Expose
    private String voteAverage;
    @SerializedName("overview")
    @Expose
    private String overview;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getFirstAirDate() {
        return firstAirDate;
    }

    public void setFirstAirDate(String firstAirDate) {
        this.firstAirDate = firstAirDate;
    }

    public String getPopularity() {
        return popularity;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }

    public String getVoteAverage() {
        return voteAverage;
    }

    public void setVoteAverage(String voteAverage) {
        this.voteAverage = voteAverage;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.posterPath);
        dest.writeString(this.name);
        dest.writeString(this.firstAirDate);
        dest.writeString(this.voteAverage);
        dest.writeString(this.popularity);
        dest.writeString(this.overview);

    }

    public TvShow(){

    }



    protected TvShow(Parcel in) {
        id = Objects.requireNonNull(in.readString());
        posterPath = in.readString();
        name = in.readString();
        firstAirDate = in.readString();
        popularity = in.readString();
        voteAverage = in.readString();
        overview = in.readString();
    }

    public static final Creator<TvShow> CREATOR = new Creator<TvShow>() {
        @Override
        public TvShow createFromParcel(Parcel source) {
            return new TvShow(source);
        }

        @Override
        public TvShow[] newArray(int size) {
            return new TvShow[size];
        }
    };
}
