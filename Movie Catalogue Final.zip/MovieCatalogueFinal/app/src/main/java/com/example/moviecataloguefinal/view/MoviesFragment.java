package com.example.moviecataloguefinal.view;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;

import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.adapter.MoviesAdapter;
import com.example.moviecataloguefinal.model.Movies;
import com.example.moviecataloguefinal.viewmodel.MoviesViewModel;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class MoviesFragment extends Fragment implements android.widget.SearchView.OnQueryTextListener {

    private final int laman = 2;
    private RecyclerView rvList;
    private SearchView svMovie;
    private MoviesAdapter adapter;
    private MoviesViewModel moviesViewModel;
    private ProgressBar pbMovies;
    private TextView tvGagal;
    private Handler mHandler;


    private final Observer<ArrayList<Movies>> observer = new Observer<ArrayList<Movies>>() {
        @Override
        public void onChanged(@Nullable ArrayList<Movies> movies) {
            if (movies != null) {
                adapter.setMovies(movies);
                setProgressBarVisible(false);

                if (movies.size() <= 0) {
                    pbMovies.setVisibility(View.GONE);
                    tvGagal.setVisibility(View.VISIBLE);
                } else {
                    tvGagal.setVisibility(View.GONE);
                }
            }
        }
    };

    public MoviesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_movies, container, false);

        tvGagal = view.findViewById(R.id.tvGagal);
        pbMovies = view.findViewById(R.id.pbMovie);
        svMovie = view.findViewById(R.id.search);
        rvList = view.findViewById(R.id.rvMovie);

        adapter = new MoviesAdapter(getActivity());
        mHandler = new Handler();

        rvList.setHasFixedSize(true);
        rvList.setLayoutManager(new LinearLayoutManager(getContext()));
        rvList.setAdapter(adapter);

        svMovie.setQueryHint("Search");
        svMovie.setOnQueryTextListener(this);

        moviesViewModel = ViewModelProviders.of(this).get(MoviesViewModel.class);
        moviesViewModel.getAllMovies().observe(getViewLifecycleOwner(), observer);

        if (adapter.getItemCount() <= 0 && (tvGagal.getVisibility() == View.GONE)) {
            moviesViewModel.loadMovies(laman);
        }

        return view;
    }

    private void setProgressBarVisible(Boolean state) {
        if (state) {
            pbMovies.setVisibility(View.VISIBLE);
            svMovie.setVisibility(View.GONE);
        } else {
            pbMovies.setVisibility(View.GONE);
            svMovie.setVisibility(View.VISIBLE);
        }
    }


    @Override
    public boolean onQueryTextSubmit(String query) {
        if (query.trim().isEmpty()) return false;

        setProgressBarVisible(true);
        adapter.deleteMovies();

        tvGagal.setVisibility(View.GONE);

        moviesViewModel.searchMovies(query);

        rvList.smoothScrollToPosition(0);
        return true;
    }

    @Override
    public boolean onQueryTextChange(String newText) {

        mHandler.removeCallbacksAndMessages(null);

        mHandler.postDelayed(() -> {
            if (TextUtils.isEmpty(newText)) {
                moviesViewModel.loadMovies(laman);
            } else {
                moviesViewModel.searchMovies(newText);
            }
        }, 300);

        return true;
    }
}
