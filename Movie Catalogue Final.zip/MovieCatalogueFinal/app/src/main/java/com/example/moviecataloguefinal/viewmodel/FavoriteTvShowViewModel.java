package com.example.moviecataloguefinal.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.moviecataloguefinal.db.FavoriteTvShowRepository;
import com.example.moviecataloguefinal.model.TvShow;

import java.util.List;

public class FavoriteTvShowViewModel extends AndroidViewModel {
    private final FavoriteTvShowRepository repository;
    private final LiveData<List<TvShow>> allTvShow;

    public FavoriteTvShowViewModel(@NonNull Application application) {
        super(application);

        repository = new FavoriteTvShowRepository(application);
        allTvShow = repository.getAllTvShow();
    }

    public void insert(TvShow tvShow, FavoriteTvShowRepository.TvShowFactoryListener listener) {
        repository.insert(tvShow, listener);
    }

    public void delete(TvShow tvShow, FavoriteTvShowRepository.TvShowFactoryListener listener) {
        repository.delete(tvShow, listener);
    }

    public void getTvShowById(int id, FavoriteTvShowRepository.TvShowFactoryListener listener) {
        repository.getTvShowById(id, listener);
    }

    public LiveData<List<TvShow>> getAllTvShow() {
        return allTvShow;
    }
}
