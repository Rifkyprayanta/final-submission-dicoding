package com.example.moviecataloguefinal.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.model.Movies;
import com.example.moviecataloguefinal.utils.CustomOnItemClickListener;
import com.example.moviecataloguefinal.view.DetailActivityMovies;

import java.util.ArrayList;

public class MoviesAdapter extends RecyclerView.Adapter<MoviesAdapter.MoviesViewHolder> {

    private String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w185";

    private final Context context;
    private final ArrayList<Movies> movies = new ArrayList<>();

    public MoviesAdapter(Context context) {
        this.context = context;
    }

    public void setMovies(ArrayList<Movies> movies) {
        this.movies.clear();
        this.movies.addAll(movies);
        notifyDataSetChanged();
    }

    public void deleteMovies() {
        this.movies.clear();
    }

    @NonNull
    @Override
    public MoviesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemRow = LayoutInflater.from(context).inflate(R.layout.item_movies, parent, false);
        return new MoviesViewHolder(itemRow);
    }

    @Override
    public void onBindViewHolder(@NonNull MoviesViewHolder holder, int i){
        holder.bind(movies.get(i));

        holder.itemView.setOnClickListener(new CustomOnItemClickListener(i, position -> {
            Intent moveIntent = new Intent(context, DetailActivityMovies.class);
            moveIntent.putExtra(DetailActivityMovies.EXTRA_MOVIES, movies.get(i));
            context.startActivity(moveIntent);
        }));
    }

    @Override
    public int getItemCount() {
        return movies.size();
    }

    public class MoviesViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        TextView tvReleaseDate;
        TextView voteAverage;
        TextView popularity;
        TextView tvOverview;
        ImageView imgPhoto;

        public MoviesViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.title);
            tvReleaseDate = itemView.findViewById(R.id.releaseDate);
            voteAverage= itemView.findViewById(R.id.voteAverage);
            popularity= itemView.findViewById(R.id.popularity);
            tvOverview = itemView.findViewById(R.id.overview);
            imgPhoto = itemView.findViewById(R.id.imgPhoto);
        }

        public void bind(Movies movies) {
            tvTitle.setText(movies.getTitle());
            tvReleaseDate.setText(movies.getReleaseDate());
            voteAverage.setText(movies.getVoteAverage() + "/10");
            popularity.setText(movies.getPopularity());
            tvOverview.setText(movies.getOverview());

            Glide.with(itemView)
                    .load(IMAGE_BASE_URL + movies.getPosterPath())
                    .apply(RequestOptions.placeholderOf(R.color.colorPrimary))
                    .into(imgPhoto);
        }
    }
}
