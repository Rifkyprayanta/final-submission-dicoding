package com.example.moviecataloguefinal.widget;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.Target;
import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.db.FavoriteMoviesRepository;
import com.example.moviecataloguefinal.model.Movies;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class StackRemoteViewsFactory implements RemoteViewsService.RemoteViewsFactory {

    private final FavoriteMoviesRepository favoriteMoviesRepository;
    private final Context mContext;
    private List<Movies> listMovies = new ArrayList<>();

    StackRemoteViewsFactory(Context context) {
        mContext = context;
        this.favoriteMoviesRepository = new FavoriteMoviesRepository((Application) context);
    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDataSetChanged() {
        listMovies = favoriteMoviesRepository.getAllMoviesAsList();

    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        return listMovies.size();
    }

    @Override
    public RemoteViews getViewAt(int position) {
        Movies movies = listMovies.get(position);
        RemoteViews rv = new RemoteViews(mContext.getPackageName(), R.layout.widget_item);

        Log.d("Widget :", movies.getTitle());

        try {
            String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500";
            Bitmap bmp = Glide.with(mContext)
                    .asBitmap()
                    .load(IMAGE_BASE_URL + movies.getPosterPath())
                    .submit(Target.SIZE_ORIGINAL, Target.SIZE_ORIGINAL)
                    .get();
            rv.setImageViewBitmap(R.id.imageView, bmp);
            rv.setTextViewText(R.id.tvTitle, movies.getTitle());
            Log.d("Widgetku","Yessh");
        }catch (InterruptedException | ExecutionException e){
            Log.d("Widget Load Error","error");
        }
        Bundle extras = new Bundle();
        extras.putInt(ImageBannerWidget.EXTRA_ITEM, position);
        Intent fillInIntent = new Intent();
        fillInIntent.putExtras(extras);

        rv.setOnClickFillInIntent(R.id.imageView, fillInIntent);
        return rv;
    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @SuppressWarnings("SameReturnValue")
    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }
}
