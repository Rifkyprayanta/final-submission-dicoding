package com.example.moviecataloguefinal.api.response;

import com.example.moviecataloguefinal.model.TvShow;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class TvShowResponse {

//    @SerializedName("page")
//    private int page;
//
//    @SerializedName("total_results")
//    private int totalResults;
//
//    @SerializedName("results")
//    private ArrayList<TvShow> tvShows;
//
//    @SerializedName("total_pages")
//    private int totalPages;
//
//    public int getPage() {
//        return page;
//    }
//
//    public void setPage(int page) {
//        this.page = page;
//    }
//
//    public int getTotalResults() {
//        return totalResults;
//    }
//
//    public void setTotalResults(int totalResults) {
//        this.totalResults = totalResults;
//    }
//
//    public ArrayList<TvShow> getTvShows() {
//        return tvShows;
//    }
//
//    public void setTvShows(ArrayList<TvShow> tvShows) {
//        this.tvShows = tvShows;
//    }
//
//    public int getTotalPages() {
//        return totalPages;
//    }
//
//    public void setTotalPages(int totalPages) {
//        this.totalPages = totalPages;
//    }

    @SerializedName("results")
    private ArrayList<TvShow> series;

    public ArrayList<TvShow> getSeries() {
        return series;
    }
}
