package com.example.moviecataloguefinal.notif;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.example.moviecataloguefinal.MainActivity;
import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.db.MovieDailyRepository;
import com.example.moviecataloguefinal.model.Movies;
import com.example.moviecataloguefinal.view.DetailActivityMovies;

import java.util.Calendar;

public class NotifReceiver extends BroadcastReceiver {

    public static final int DAILY_ALARM_ID = 101;
    public static final int RELEASE_ALARM_ID = 110;

    private static final String EXTRA_ALARM_ID = "NotifReceiver.alarmId";


    @Override
    public void onReceive(Context context, Intent intent) {
        int alarmId = intent.getIntExtra(EXTRA_ALARM_ID, DAILY_ALARM_ID);

        if (alarmId == RELEASE_ALARM_ID)
            new MovieDailyRepository(context).getReleaseNow(movies -> {
                if (movies == null || movies.size() <= 0) {
                    showAlarmNotification(context, context.getString(R.string.bad_news), context.getString(R.string.no_new_movie), alarmId, 0);
                    return;
                }

                for (int i = 0; i < movies.size(); i++) {
                    Movies movie = movies.get(i);

                    String message = context.getResources().getString(R.string.rilis_now, movie.getTitle());

                    showAlarmNotification(context, context.getString(R.string.release_reminder), message, alarmId + 1 + i, Integer.parseInt(movie.getId()));
                }

            }, "popularity.asc");
        else {
            showAlarmNotification(context, context.getString(R.string.daily_reminder), context.getString(R.string.daily_reminder_message), alarmId, 0);
        }
    }

    public void setAlarm(Context context, int alarmId, int hour) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent(context, NotifReceiver.class);

        intent.putExtra(EXTRA_ALARM_ID, alarmId);

        Calendar calendar = Calendar.getInstance();

        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, alarmId, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        if (alarmManager != null) {
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);
        }
    }

    public void cancelAlarm(Context context, int alarmId) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent(context, NotifReceiver.class);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, alarmId, intent, 0);

        pendingIntent.cancel();

        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent);
        }
    }

    private void showAlarmNotification(Context context, String title, String message, int notificationId, int movieId) {
        String CHANNEL_ID = "Channel_1";
        String CHANNEL_NAME = "Reminder";

        NotificationManager notificationManagerCompat = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_movie_black_24dp)
                .setContentTitle(title)
                .setContentText(message)
                .setColor(ContextCompat.getColor(context, android.R.color.transparent))
                .setSound(alarmSound)
                .setAutoCancel(true);

        PendingIntent pendingIntent = getPendingIntent(context, notificationId, movieId);

        if (pendingIntent != null) {
            builder.setContentIntent(pendingIntent);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_DEFAULT
            );

            builder.setChannelId(CHANNEL_ID);

            if (notificationManagerCompat != null) {
                notificationManagerCompat.createNotificationChannel(channel);
            }
        }

        Notification notification = builder.build();

        if (notificationManagerCompat != null) {
            Log.d("NotifReceiver", "showAlarmNotification: " + notificationId);
            notificationManagerCompat.notify(notificationId, notification);
        }

    }

    private PendingIntent getPendingIntent(Context context, int notificationId, int movieId) {
        Intent intent;

        if (notificationId == DAILY_ALARM_ID) {
            intent = new Intent(context.getApplicationContext(), MainActivity.class);
        } else if (notificationId >= RELEASE_ALARM_ID) {
            intent = new Intent(context.getApplicationContext(), DetailActivityMovies.class);
            intent.putExtra(DetailActivityMovies.MOVIE_ID, movieId);
        } else {
            return null;
        }

        return PendingIntent.getActivity(context.getApplicationContext(), notificationId == DAILY_ALARM_ID ? notificationId : movieId, intent, 0);
    }
}
