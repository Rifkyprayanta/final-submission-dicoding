package com.example.moviecataloguefinal.db;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.moviecataloguefinal.model.TvShow;

import java.util.List;

public class FavoriteTvShowRepository {

    private final TvShowDao tvShowDao;
    private final LiveData<List<TvShow>> allTvShow;

    public FavoriteTvShowRepository(Application application) {
        FavDb database = FavDb.getInstance(application);
        tvShowDao = database.tvShowDao();
        allTvShow = tvShowDao.getAllTvShow();
    }

    public void insert(TvShow tvShow, FavoriteTvShowRepository.TvShowFactoryListener listener) {
        new FavoriteTvShowRepository.InsertTvShowTask(tvShowDao, listener).execute(tvShow);
    }

    public void delete(TvShow tvShow, FavoriteTvShowRepository.TvShowFactoryListener listener) {
        new FavoriteTvShowRepository.DeleteTvShowTask(tvShowDao, listener).execute(tvShow);
    }

    public LiveData<List<TvShow>> getAllTvShow() {
        return allTvShow;
    }

    public void getTvShowById(int id, FavoriteTvShowRepository.TvShowFactoryListener listener) {
        new FavoriteTvShowRepository.GetTvShowByIdTask(tvShowDao, listener).execute(id);
    }

    public interface TvShowFactoryListener {
        void onTvShowReceived(TvShow tvShow);

        void onTvShowInserted();

        void onTvShowDeleted();
    }

    private static class InsertTvShowTask extends AsyncTask<TvShow, Void, Void> {
        private final TvShowDao tvShowDao;
        private final FavoriteTvShowRepository.TvShowFactoryListener listener;

        InsertTvShowTask(TvShowDao tvShowDao, FavoriteTvShowRepository.TvShowFactoryListener listener) {
            this.tvShowDao = tvShowDao;
            this.listener = listener;
        }

        @Override
        protected Void doInBackground(TvShow... tvShows) {
            tvShowDao.insert(tvShows[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            listener.onTvShowInserted();
        }
    }

    private static class DeleteTvShowTask extends AsyncTask<TvShow, Void, Void> {
        private final TvShowDao tvShowDao;
        private final FavoriteTvShowRepository.TvShowFactoryListener listener;

        DeleteTvShowTask(TvShowDao tvShowDao, FavoriteTvShowRepository.TvShowFactoryListener listener) {
            this.tvShowDao = tvShowDao;
            this.listener = listener;
        }

        @Override
        protected Void doInBackground(TvShow... tvShows) {
            tvShowDao.delete(tvShows[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            listener.onTvShowDeleted();
        }
    }

    private static class GetTvShowByIdTask extends AsyncTask<Integer, Void, Void> {
        private final TvShowDao tvShowDao;
        private TvShow tvShow;
        private final FavoriteTvShowRepository.TvShowFactoryListener listener;

        GetTvShowByIdTask(TvShowDao tvShowDao, FavoriteTvShowRepository.TvShowFactoryListener listener) {
            this.tvShowDao = tvShowDao;
            this.listener = listener;
        }

        @Override
        protected Void doInBackground(Integer... ints) {
            tvShow = tvShowDao.getTvShowById(ints[0]);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            listener.onTvShowReceived(tvShow);
        }
    }
}
