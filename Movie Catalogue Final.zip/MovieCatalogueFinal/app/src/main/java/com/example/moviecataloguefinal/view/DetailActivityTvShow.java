package com.example.moviecataloguefinal.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.db.FavoriteTvShowRepository;
import com.example.moviecataloguefinal.model.TvShow;
import com.example.moviecataloguefinal.viewmodel.FavoriteTvShowViewModel;

public class DetailActivityTvShow extends AppCompatActivity {

    private String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w185";

    public static final String EXTRA_TVSHOWS = "Detail TV Shows";

    ImageView imgPhoto;
    ImageButton btnFav;
    TextView tvTitle, tvReleaseDate, tvVoteAverage, tvPopularity, tvOverview;

    private FavoriteTvShowViewModel favoriteTvShowViewModel;
    private boolean isFav = true;
    TvShow tvShow;

    private final FavoriteTvShowRepository.TvShowFactoryListener tvShowFactoryListener = new FavoriteTvShowRepository.TvShowFactoryListener()
    {
        @Override
        public void onTvShowReceived(TvShow tvShow) {
            if (tvShow == null)
                isFav = false;
            updateDataFav();
        }

        @Override
        public void onTvShowInserted() {
            isFav = true;
            updateDataFav();
        }

        @Override
        public void onTvShowDeleted() {
            isFav = false;
            updateDataFav();
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movies);

        imgPhoto = findViewById(R.id.imgFoto);
        tvTitle = findViewById(R.id.tvTitle);
        tvReleaseDate = findViewById(R.id.tvReleaseDate);
        tvVoteAverage = findViewById(R.id.tvVoteAverage);
        tvPopularity = findViewById(R.id.tvPopularity);
        tvOverview = findViewById(R.id.tvOverview);

        btnFav = findViewById(R.id.btnFav);

        tvShow = getIntent().getParcelableExtra(EXTRA_TVSHOWS);

        updateDataFav();

        favoriteTvShowViewModel = ViewModelProviders.of(this).get(FavoriteTvShowViewModel.class);
        favoriteTvShowViewModel.getTvShowById(Integer.parseInt(tvShow.getId()), tvShowFactoryListener);

        Glide.with(this)
                .load(IMAGE_BASE_URL + tvShow.getPosterPath())
                .apply(RequestOptions.placeholderOf(R.color.colorPrimary))
                .into(imgPhoto);

        tvTitle.setText(tvShow.getName());
        tvReleaseDate.setText(tvShow.getFirstAirDate());
        tvVoteAverage.setText(tvShow.getVoteAverage() + "/10");
        tvPopularity.setText(tvShow.getPopularity());
        tvOverview.setText(tvShow.getOverview());


    }

    private void updateDataFav() {
        if (isFav) {
            btnFav.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_heart_icon_fill));
            btnFav.setOnClickListener(v -> favoriteTvShowViewModel.delete(tvShow, tvShowFactoryListener));
        } else {
            btnFav.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_heart_icon));
            btnFav.setOnClickListener(v -> favoriteTvShowViewModel.insert(tvShow, tvShowFactoryListener));
        }
    }
}
