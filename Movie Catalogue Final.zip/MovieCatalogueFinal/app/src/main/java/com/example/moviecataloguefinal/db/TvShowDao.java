package com.example.moviecataloguefinal.db;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.moviecataloguefinal.model.TvShow;

import java.util.List;

@Dao
public interface TvShowDao {

    @Insert
    void insert(TvShow tvShow);

    @Delete
    void delete(TvShow tvShow);

    @Query("SELECT * FROM tvShow")
    LiveData<List<TvShow>> getAllTvShow();

    @Query("SELECT * FROM tvShow WHERE id=:id")
    TvShow getTvShowById(int id);
}
