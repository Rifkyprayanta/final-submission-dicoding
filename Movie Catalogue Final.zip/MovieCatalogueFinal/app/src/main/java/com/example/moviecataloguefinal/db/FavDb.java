package com.example.moviecataloguefinal.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.moviecataloguefinal.model.Movies;
import com.example.moviecataloguefinal.model.TvShow;

@Database(entities = {Movies.class, TvShow.class}, version = 1, exportSchema = false)
public abstract class FavDb extends RoomDatabase {

    private static FavDb instance;

    public static synchronized FavDb getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    FavDb.class, "favdb")
                    .fallbackToDestructiveMigration()
                    .build();
        }

        return instance;
    }

    public abstract MoviesDao moviesDao();

    public abstract TvShowDao tvShowDao();
}
