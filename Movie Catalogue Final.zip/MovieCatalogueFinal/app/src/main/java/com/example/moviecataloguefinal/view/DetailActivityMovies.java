package com.example.moviecataloguefinal.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.moviecataloguefinal.R;
import com.example.moviecataloguefinal.db.FavoriteMoviesRepository;
import com.example.moviecataloguefinal.model.Movies;
import com.example.moviecataloguefinal.viewmodel.FavoriteMoviesViewModel;

public class DetailActivityMovies extends AppCompatActivity {

    private String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w185";
    public static final String MOVIE_ID = "extra_movie_id";

    ImageView imgPhoto;
    ImageButton btnFav;
    TextView tvTitle, tvReleaseDate, tvVoteAverage, tvPopularity, tvOverview;

    private FavoriteMoviesViewModel favoriteMoviesViewModel;
    private boolean isFav = true;
    Movies movies;

    private final FavoriteMoviesRepository.MoviesFactoryListener moviesFactoryListener = new FavoriteMoviesRepository.MoviesFactoryListener()
    {
        @Override
        public void onMoviesReceived(Movies movies) {
            if (movies == null)
                isFav = false;
            updateDataFav();
        }

        @Override
        public void onMoviesInserted() {
            isFav = true;
            updateDataFav();
        }

        @Override
        public void onMoviesDeleted() {
            isFav = false;
            updateDataFav();
        }

    };

    public static final String EXTRA_MOVIES = "extra_movie";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movies);

        imgPhoto = findViewById(R.id.imgFoto);
        tvTitle = findViewById(R.id.tvTitle);
        tvReleaseDate = findViewById(R.id.tvReleaseDate);
        tvVoteAverage = findViewById(R.id.tvVoteAverage);
        tvPopularity = findViewById(R.id.tvPopularity);
        tvOverview = findViewById(R.id.tvOverview);

        btnFav = findViewById(R.id.btnFav);

        movies = getIntent().getParcelableExtra(EXTRA_MOVIES);

        updateDataFav();

        favoriteMoviesViewModel = ViewModelProviders.of(this).get(FavoriteMoviesViewModel.class);
        favoriteMoviesViewModel.getMovieById(Integer.parseInt(movies.getId()), moviesFactoryListener);

        Glide.with(DetailActivityMovies.this)
                .load(IMAGE_BASE_URL + movies.getPosterPath())
                .apply(RequestOptions.placeholderOf(R.color.colorPrimary))
                .into(imgPhoto);

        tvTitle.setText(movies.getTitle());
        tvReleaseDate.setText(movies.getReleaseDate());
        tvVoteAverage.setText(movies.getVoteAverage() + "/10");
        tvPopularity.setText(movies.getPopularity());
        tvOverview.setText(movies.getOverview());
    }

    private void updateDataFav() {
        if (isFav) {
            btnFav.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_heart_icon_fill));
            btnFav.setOnClickListener(v -> favoriteMoviesViewModel.delete(movies, moviesFactoryListener));
        } else {
            btnFav.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_heart_icon));
            btnFav.setOnClickListener(v -> favoriteMoviesViewModel.insert(movies, moviesFactoryListener));
        }
    }
}
