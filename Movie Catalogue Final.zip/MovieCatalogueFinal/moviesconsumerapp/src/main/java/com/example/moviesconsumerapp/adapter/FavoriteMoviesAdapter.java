package com.example.moviesconsumerapp.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.moviesconsumerapp.R;
import com.example.moviesconsumerapp.model.Movies;

import java.util.ArrayList;

public class FavoriteMoviesAdapter extends RecyclerView.Adapter<FavoriteMoviesAdapter.FavoriteMoviesViewHolder> {

    private String IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w185";

    private final ArrayList<Movies> movies = new ArrayList<>();
    private final Activity activity;

    public FavoriteMoviesAdapter(Activity activity) {
        this.activity = activity;
    }

    public void setMovies(ArrayList<Movies> movies) {
        this.movies.clear();
        this.movies.addAll(movies);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FavoriteMoviesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemRow = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_movies, parent, false);
        return new FavoriteMoviesViewHolder(itemRow);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteMoviesViewHolder holder, int i) {
        holder.bind(movies.get(i));
    }

    @Override
    public int getItemCount() {
        return movies.size();
    }

    class FavoriteMoviesViewHolder extends RecyclerView.ViewHolder
    {
        TextView tvTitle;
        TextView tvOverview;
        ImageView imgPhoto;

        public FavoriteMoviesViewHolder (View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.title);
            tvOverview = itemView.findViewById(R.id.overview);
            imgPhoto = itemView.findViewById(R.id.imgPhoto);
        }

        public void bind(Movies movies) {
            tvTitle.setText(movies.getTitle());
            tvOverview.setText(movies.getOverview());

            Glide.with(itemView)
                    .load(IMAGE_BASE_URL + movies.getPosterPath())
                    .apply(RequestOptions.placeholderOf(R.color.colorPrimary))
                    .into(imgPhoto);
        }
    }
}
