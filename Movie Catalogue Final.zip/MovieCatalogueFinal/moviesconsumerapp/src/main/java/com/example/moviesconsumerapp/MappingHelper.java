package com.example.moviesconsumerapp;

import android.database.Cursor;

import com.example.moviesconsumerapp.model.Movies;

import java.util.ArrayList;

import static android.provider.BaseColumns._ID;

import static com.example.moviesconsumerapp.db.MoviesContract.MoviesColumns.COLUMN_TITLE;
import static com.example.moviesconsumerapp.db.MoviesContract.MoviesColumns.COLUMN_POSTER;
import static com.example.moviesconsumerapp.db.MoviesContract.MoviesColumns.COLUMN_OVERVIEW;


public class MappingHelper {

    public static ArrayList<Movies> mapCursorToArrayList(Cursor cursor) {
        ArrayList<Movies> moviesList = new ArrayList<>();

        while (cursor.moveToNext()) {
            String id = cursor.getString(cursor.getColumnIndexOrThrow(_ID));
            String title = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE));
            String posterPath = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_POSTER));
            String overview = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_OVERVIEW));
            moviesList.add(new Movies(id, title, posterPath, overview));
        }
        return moviesList;
    }
}
