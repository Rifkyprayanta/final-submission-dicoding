package com.example.moviesconsumerapp.model;

import android.content.ContentValues;
import android.os.Parcel;
import android.os.Parcelable;
import android.provider.BaseColumns;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Objects;

@Entity(tableName = Movies.TABLE_NAME)
public class Movies implements Parcelable {

    public static final String TABLE_NAME = "movies";

    public static final String COLUMN_ID = BaseColumns._ID;

    public static final String COLUMN_TITLE = "title";

    public static final String COLUMN_POSTER = "posterPath";

    public static final String COLUMN_OVERVIEW = "overview";

    @NonNull
    @PrimaryKey
    @ColumnInfo(index = true, name = COLUMN_ID)
    @SerializedName("id")
    private String id;

    @ColumnInfo(name = COLUMN_POSTER)
    @SerializedName("poster_path")
    @Expose
    private String posterPath;

    @ColumnInfo(name = COLUMN_TITLE)
    @SerializedName("title")
    @Expose
    private String title;

    @SerializedName("release_date")
    @Expose
    private String releaseDate;

    @SerializedName("vote_average")
    @Expose
    private String voteAverage;

    @SerializedName("popularity")
    @Expose
    private String  popularity;

    @ColumnInfo(name = COLUMN_OVERVIEW)
    @SerializedName("overview")
    @Expose
    private String overview;

    public static Movies fromContentValues(ContentValues values) {
        final Movies movies = new Movies();
        if (values.containsKey(COLUMN_ID)) {
            movies.id = values.getAsString(COLUMN_ID);
        }
        if (values.containsKey(COLUMN_TITLE)) {
            movies.title = values.getAsString(COLUMN_TITLE);
        }
        if (values.containsKey(COLUMN_POSTER)) {
            movies.posterPath = values.getAsString(COLUMN_POSTER);
        }
        if (values.containsKey(COLUMN_OVERVIEW)) {
            movies.overview = values.getAsString(COLUMN_OVERVIEW);
        }
        return movies;
    }

    public String getId() {
        return id;
    }

    public void setId(@NonNull String id) {
        this.id = id;
    }


    public String getPosterPath() {
        return posterPath;
    }

    public void setPosterPath(String posterPath) {
        this.posterPath = posterPath;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getVoteAverage() {
        return voteAverage;
    }

    public void setVoteAverage(String voteAverage) {
        this.voteAverage = voteAverage;
    }

    public String getPopularity() {
        return popularity;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.posterPath);
        dest.writeString(this.title);
        dest.writeString(this.releaseDate);
        dest.writeString(this.voteAverage);
        dest.writeString(this.popularity);
        dest.writeString(this.overview);

    }

    public Movies(){
    }

    public Movies(String id, String title, String posterPath, String overview) {
        this.id = id;
        this.title = title;
        this.posterPath = posterPath;
        this.overview = overview;
    }

    protected Movies(Parcel in){
        this.id = Objects.requireNonNull(in.readString());
        this.posterPath = in.readString();
        this.title = in.readString();
        this.releaseDate = in.readString();
        this.voteAverage = in.readString();
        this.popularity = in.readString();
        this.overview = in.readString();
    }

    public static final Parcelable.Creator<Movies> CREATOR = new Parcelable.Creator<Movies>() {
        @Override
        public Movies createFromParcel(Parcel source) {
            return new Movies(source);
        }

        @Override
        public Movies[] newArray(int size) {
            return new Movies[size];
        }
    };
}
